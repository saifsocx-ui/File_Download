# Wazuh SOC Playbooks — source package / staging candidate

This is a native Dashboard application, not an iframe or public website. After building and installing, the Wazuh navigation menu gains **SOC Playbooks** at `/app/socPlaybooks` (include your configured base path). It is a separate native app in the existing dashboard shell, not a change to Wazuh's own Overview screen.

## Included
17 existing DWP SOPs, searchable ES use-case catalogue, domain filters, step checklists, session-only notes, verdict and text export. Existing DWP IRIS templates are included separately. Wazuh-inspired blue styling; the host's existing Wazuh logo/navigation remains in place. No third-party logo is bundled. Exact screenshot matching was unavailable.

ES Rules here means the supplied SOP references, **not verified installed Wazuh detection rules**. No detection XML or rule coverage is invented. All rule mappings and owner approvals remain pending. Edit `soc_playbooks/data/playbooks.json` after verifying rule IDs, then rebuild.

## 1. Check the actual installed version — on Wazuh dashboard host
```bash
sudo /usr/share/wazuh-dashboard/node/bin/node -e 'const p=require("/usr/share/wazuh-dashboard/package.json"); console.log(JSON.stringify({version:p.version,wazuh:p.wazuh},null,2))'
sudo /usr/share/wazuh-dashboard/bin/opensearch-dashboards-plugin list
```
This candidate targets underlying OpenSearch Dashboards **2.19.6** (reported for Wazuh 4.14.8 revision 02). Do not install into another version. Retain the output to select the matching Wazuh source tag; do not assume every 4.14.8 build has the same base version.

## 2. Build on an isolated build machine, not the production host
Use the exact matching Wazuh dashboard checkout and its documented Node/Yarn versions. Place only `soc_playbooks` in its `plugins` folder. With the matching repository dependencies bootstrapped:
```bash
cd /path/to/matching-wazuh-dashboard
# Follow the checkout's DEVELOPER_GUIDE.md for dependency bootstrap.
cd plugins/soc_playbooks
yarn build
```
The official plugin helper creates the distributable ZIP in `build/`. The ZIP you downloaded here is **source**, not that distributable; do not pass it to the plugin installer. Run TypeScript/lint checks against the matching checkout before installation. Fix API/type differences there rather than suppressing them.

## 3. Stage installation and access configuration
Back up dashboard configuration and record plugin inventory. Copy the built ZIP to a private staging dashboard. Add the following config key to `/etc/wazuh-dashboard/opensearch_dashboards.yml`, using a real, approved backend role assigned to your SOC analysts:
```yaml
socPlaybooks.allowed_backend_roles: ["soc_analyst"]
```
`SOC role` refers to the indexer Security backend role, not a Wazuh manager API role. Configure it through the existing Security administration process. An empty list denies everyone. Do not disable security, change global anonymous access, or add broad roles just to make the page load.

Install **the built artifact** using the dashboard's supported plugin installer and service account:
```bash
sudo -u wazuh-dashboard /usr/share/wazuh-dashboard/bin/opensearch-dashboards-plugin install file:///absolute/path/to/BUILT_PLUGIN.zip
sudo systemctl restart wazuh-dashboard
```
Adjust service account for your actual installation. Do not install the source ZIP. Docker installations require a custom image and staging procedure rather than these systemd commands.

## 4. Acceptance before production
- Approved SOC role can open the app and retrieve the catalogue.
- Unauthenticated requests are denied by existing dashboard authentication.
- Authenticated non-SOC user receives 403 from `/api/soc_playbooks/catalogue` (not merely a hidden menu).
- Empty roles and an unavailable Security authinfo endpoint both deny access.
- Test with the actual security plugin: asCurrentUser must preserve the caller identity.
- Search all 17 guides, category filter, checkbox state, export and responsive layout.
- Inject `<img src=x onerror=alert(1)>` into a staging guide: it must display literally.
- Confirm no guide content occurs in the built public JS bundles; no external network requests.
- Open existing Wazuh views and confirm normal access; test base path and CSP.
- SOP owner approves instructions, mappings, role assignments and handling of downloaded records.
- Verify this is documentation only: no automatic containment, alert closure or IRIS writes.

## Rollback
On staging, then production if needed:
```bash
sudo -u wazuh-dashboard /usr/share/wazuh-dashboard/bin/opensearch-dashboards-plugin remove socPlaybooks
```
Remove only the `socPlaybooks.allowed_backend_roles` config key, then restart dashboard. Preserve existing Wazuh/security plugins and configuration.

## Security design and limits
Guides are imported exclusively by server code. One read-only route authorizes the current indexer user via the Security authinfo API, checks explicit backend-role membership, and fails closed. Responses use no-store. Rendering uses textContent, no raw HTML, eval, remote scripts, credentials or service-user access. Checklists/notes are memory-only; leaving loses them. Downloaded drafts contain sensitive evidence and require your normal handling controls. Menu visibility is not authorization: non-SOC users may see the navigation title but cannot retrieve the guides. Anyone granted the approved role can read all guides; no per-guide ACL exists. Repository/source/preview files themselves contain sensitive SOPs and must stay private. Server administrators can inspect installed data.

This design has not undergone an independent penetration test. Matching-version build, real auth integration, browser visual QA, staging install and production deployment are pending. No live server was changed.

## References
https://opensearch.org/blog/dashboards-plugins-intro/
https://github.com/wazuh/wazuh-dashboard-plugins/releases
https://github.com/wazuh/wazuh-dashboard/blob/main/DEVELOPER_GUIDE.md
