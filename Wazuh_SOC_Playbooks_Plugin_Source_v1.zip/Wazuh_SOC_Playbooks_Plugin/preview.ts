export function mount(root: HTMLElement, http: any) {
  let disposed = false;
  const el = (tag: string, text = '', cls = '') => { const n = document.createElement(tag); n.textContent = text; n.className = cls; return n; };
  const shell = el('div', '', 'socPlaybooks'); root.append(shell);
  const header = el('header'); header.append(el('span','WAZUH · SOC OPERATIONS','eyebrow'),el('h1','Investigation playbooks'),el('p','Find the use case. Follow the evidence. Document your decision.')); shell.append(header);
  const status = el('p','Loading protected catalogue…'); shell.append(status);
  const state = new Map<string, {checks: Set<string>, notes: string, verdict: string}>();
  const draw = (data: any[]) => {
    status.remove();
    const metrics = el('div','','metrics');
    for(const [v,label] of [[data.length,'Investigation guides'],[new Set(data.map(p=>p.category)).size,'Security domains'],[data.filter(p=>p.rule_ids.length).length,'Mapped rules']]) { const c=el('div');c.append(el('strong',String(v)),el('span',String(label)));metrics.append(c); } shell.append(metrics);
    const controls=el('div','','controls'); const search=el('input') as HTMLInputElement;search.type='search'; search.placeholder='Search ES use case, rule ID or technique';search.setAttribute('aria-label','Search playbooks');
    const filter=el('select') as HTMLSelectElement;filter.setAttribute('aria-label','Security domain');
    for(const c of ['',...Array.from(new Set(data.map(p=>p.category))).sort()]) {const o=el('option',c || 'All security domains') as HTMLOptionElement;o.value=c;filter.append(o);}
    controls.append(search,filter);shell.append(controls);
    const body=el('div','','layout'),list=el('nav','','catalogue'),detail=el('article','','detail'); list.setAttribute('aria-label','ES use cases');body.append(list,detail);shell.append(body);
    let selected=data[0]?.id;
    const show=(p:any)=>{
      selected=p.id;detail.replaceChildren(); let s=state.get(p.id);if(!s){s={checks:new Set(),notes:'',verdict:'UNDETERMINED'};state.set(p.id,s);} const current=s;
      detail.append(el('span',p.id+' · '+p.category,'eyebrow'),el('h2',p.title),el('p',p.status,'badge'));
      const section=(title:string, items:string[],check=false)=>{const box=el('section');box.append(el('h3',title));items.forEach((text,i)=>{if(check){const label=el('label','','step'),input=el('input') as HTMLInputElement;input.type='checkbox';const key=title+i;input.checked=current.checks.has(key);input.onchange=()=>{input.checked?current.checks.add(key):current.checks.delete(key);};label.append(input,el('span',text));box.append(label);}else box.append(el('p',text));});detail.append(box);};
      section('Detection & ES rule reference',[p.source_trigger,'Telemetry: '+p.telemetry,'Source: '+p.source_file+' / '+p.source_sheet,'Wazuh rule IDs: '+(p.rule_ids.join(', ')||'Mapping pending — detection coverage not verified')]);
      section('1 · Initial triage',p.triage,true);section('2 · Investigate',p.investigation,true);section('3 · Escalate & respond',[p.escalation,...p.response],true);section('4 · Closure criteria',[p.closure_requirement,...p.decisions]);section('Review gaps',p.gaps);
      const closure=el('section');closure.append(el('h3','Investigation record · session draft'));
      const verdict=el('select') as HTMLSelectElement;verdict.setAttribute('aria-label','Verdict');for(const v of ['UNDETERMINED','TRUE_POSITIVE','FALSE_POSITIVE','BENIGN_AUTHORIZED','AUTHORIZED_TEST','DUPLICATE']){const o=el('option',v) as HTMLOptionElement;o.value=v;verdict.append(o);} verdict.value=current.verdict;verdict.onchange=()=>current.verdict=verdict.value;
      const notes=el('textarea') as HTMLTextAreaElement;notes.setAttribute('aria-label','Evidence and closure notes');notes.placeholder='Alert/case ID, host/user, time window, evidence, rationale, approved actions, outcome, reviewer and remaining gaps…';notes.value=current.notes;notes.oninput=()=>current.notes=notes.value;
      const exportButton=el('button','Download investigation draft');exportButton.onclick=()=>{const text=['# '+p.title,p.id+' / version '+p.version,'Verdict: '+current.verdict,'Checked steps: '+current.checks.size,'Evidence and closure notes:',current.notes,'Draft only. Record evidence and obtain required review in IRIS/Jira.'].join('\n\n');const url=URL.createObjectURL(new Blob([text],{type:'text/plain'}));const a=el('a') as HTMLAnchorElement;a.href=url;a.download=p.id+'-investigation.txt';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);};
      closure.append(verdict,notes,exportButton,el('p','Notes stay in memory until you leave or reload. Export to your approved case system. This page does not close alerts.'));detail.append(closure);
      for(const b of Array.from(list.querySelectorAll('button'))) b.setAttribute('aria-pressed',String(b.dataset.id===selected));
    };
    const renderList=()=>{list.replaceChildren();const q=search.value.toLowerCase().trim(); const rows=data.filter(p=>(!filter.value||p.category===filter.value)&&[p.title,p.id,p.category,p.source_sheet,...p.rule_ids].join(' ').toLowerCase().includes(q)); if(!rows.length){list.append(el('p','No matching use cases'));detail.replaceChildren(el('p','Change your search or domain filter.'));return;}for(const p of rows){const b=el('button') as HTMLButtonElement;b.dataset.id=p.id;b.append(el('span',p.category,'eyebrow'),el('strong',p.title),el('small',p.rule_ids.length?'Rule '+p.rule_ids.join(', '):'Rule mapping pending'));b.onclick=()=>show(p);list.append(b);}show(rows.find(p=>p.id===selected)||rows[0]);};
    search.oninput=renderList;filter.onchange=renderList;renderList();
  };
  http.get('/api/soc_playbooks/catalogue').then((data:any)=>{if(!disposed)draw(data);}).catch(()=>{if(!disposed)status.textContent='Access unavailable. Ask your administrator to verify your SOC role and plugin configuration.';});
  return ()=>{disposed=true;state.clear();shell.remove();};
}

mount(document.getElementById("app")!, {get:async()=>[
  {
    "id": "DWP-SOP-001",
    "title": "Recurring malware infection",
    "category": "Endpoint",
    "version": "1.0",
    "status": "DRAFT — lead approval and rule mapping pending",
    "source_file": "ES_Rules_SOP.xlsx",
    "source_sheet": "Recurring",
    "source_trigger": "Source describes infection recurring or not cleaned for more than 3 days.",
    "telemetry": "AV/EDR detections, remediation actions, host inventory and process/file telemetry.",
    "rule_ids": [],
    "triage": [
      "Open the Wazuh alert, record event ID, rule.id, rule.description, rule.level, timestamp, agent.name and raw event.",
      "Set an explicit investigation time range; confirm timezone and ingestion delay. Search related alerts and existing IRIS/Jira records.",
      "Identify asset owner/criticality and user; preserve original logs. Mark missing telemetry as unknown, not benign.",
      "Assign the analyst and record the use-case SOP/version. Keep the case open while evidence or approval is pending."
    ],
    "investigation": [
      "Link previous detections and cases for the same host, hash or malware family; separate repeat reporting from a new infection.",
      "Record malware name, file path, hash, first/last seen and each AV/EDR action. Confirm whether quarantine or cleanup actually succeeded.",
      "Reconstruct parent process and execution timeline; check startup entries, scheduled tasks and other persistence supported by available telemetry.",
      "Compare reinfection with software changes, downloads, shared locations and other affected hosts. Identify the recurring source."
    ],
    "escalation": "Repeated verified execution, failed cleanup, persistence, multiple affected assets or policy violation.",
    "response": [
      "Notify the shift lead/incident lead with affected assets, evidence, severity rationale and business impact. Follow the approved response/communication process.",
      "Request containment, account/session changes or blocking only through the authorized owner and procedure. This package executes no containment.",
      "Record actions, approval, timestamps and results; collect post-action evidence and monitor recurrence. Tuning/allowlisting requires documented scope, owner, expiry and review."
    ],
    "closure_requirement": "Document successful cleanup and the agreed monitoring period without recurrence; link remediation and root-cause evidence.",
    "decisions": [
      "TRUE_POSITIVE: the detection represents a verified security incident; record corroborating evidence and response scope.",
      "FALSE_POSITIVE: the detection logic or interpretation was incorrect; document the contradiction and propose narrowly scoped tuning for lead review.",
      "BENIGN_AUTHORIZED: the observed behavior occurred and was approved; cite purpose, owner and approval. Do not label every authorized activity a false positive.",
      "AUTHORIZED_TEST: explicitly approved validation activity; record test scope and assessment source.",
      "DUPLICATE: link the active investigation and confirm ownership; do not discard new evidence.",
      "UNDETERMINED: insufficient evidence; record gaps and next actions, keep review open and escalate as appropriate."
    ],
    "gaps": [
      "The referenced Malware Processing Checklist was not supplied.",
      "Source PUP/PUA exclusions are not adopted without approval."
    ]
  },
  {
    "id": "DWP-SOP-002",
    "title": "Malware outbreak",
    "category": "Endpoint",
    "version": "1.0",
    "status": "DRAFT — lead approval and rule mapping pending",
    "source_file": "ES_Rules_SOP.xlsx",
    "source_sheet": "Outbreak",
    "source_trigger": "Source describes the same detection on more than 10 machines in 24 hours.",
    "telemetry": "AV/EDR detections with stable host identifiers and timestamps; host criticality and containment history.",
    "rule_ids": [],
    "triage": [
      "Open the Wazuh alert, record event ID, rule.id, rule.description, rule.level, timestamp, agent.name and raw event.",
      "Set an explicit investigation time range; confirm timezone and ingestion delay. Search related alerts and existing IRIS/Jira records.",
      "Identify asset owner/criticality and user; preserve original logs. Mark missing telemetry as unknown, not benign.",
      "Assign the analyst and record the use-case SOP/version. Keep the case open while evidence or approval is pending."
    ],
    "investigation": [
      "Count distinct hosts within the source time window; remove duplicates and confirm detection names/hashes represent the same threat.",
      "Build an affected-host list with first/last seen, location, owner and remediation state.",
      "Correlate a shared deployment, downloaded file, email, network share or recent vulnerability exposure.",
      "Determine whether infection is spreading or detections are retrospective; prioritize active execution and critical assets."
    ],
    "escalation": "Verified spread, multiple compromised hosts, failed remediation or impact to a critical service.",
    "response": [
      "Notify the shift lead/incident lead with affected assets, evidence, severity rationale and business impact. Follow the approved response/communication process.",
      "Request containment, account/session changes or blocking only through the authorized owner and procedure. This package executes no containment.",
      "Record actions, approval, timestamps and results; collect post-action evidence and monitor recurrence. Tuning/allowlisting requires documented scope, owner, expiry and review."
    ],
    "closure_requirement": "Reconcile every affected host, verify remediation and record the agreed no-recurrence monitoring result.",
    "decisions": [
      "TRUE_POSITIVE: the detection represents a verified security incident; record corroborating evidence and response scope.",
      "FALSE_POSITIVE: the detection logic or interpretation was incorrect; document the contradiction and propose narrowly scoped tuning for lead review.",
      "BENIGN_AUTHORIZED: the observed behavior occurred and was approved; cite purpose, owner and approval. Do not label every authorized activity a false positive.",
      "AUTHORIZED_TEST: explicitly approved validation activity; record test scope and assessment source.",
      "DUPLICATE: link the active investigation and confirm ownership; do not discard new evidence.",
      "UNDETERMINED: insufficient evidence; record gaps and next actions, keep review open and escalate as appropriate."
    ],
    "gaps": [
      "Threshold is a source design value, not verified Wazuh coverage.",
      "Malware response checklist and asset-owner communication template were referenced but not supplied."
    ]
  },
  {
    "id": "DWP-SOP-003",
    "title": "DMZ firewall attacks and scans",
    "category": "Network",
    "version": "1.0",
    "status": "DRAFT — lead approval and rule mapping pending",
    "source_file": "ES_Rules_SOP.xlsx",
    "source_sheet": "PA DMZ",
    "source_trigger": "Source aggregates DMZ attack/scan events by source over 8 hours.",
    "telemetry": "Firewall threat/session logs, DMZ asset inventory, action values, signatures and approved packet capture where available.",
    "rule_ids": [],
    "triage": [
      "Open the Wazuh alert, record event ID, rule.id, rule.description, rule.level, timestamp, agent.name and raw event.",
      "Set an explicit investigation time range; confirm timezone and ingestion delay. Search related alerts and existing IRIS/Jira records.",
      "Identify asset owner/criticality and user; preserve original logs. Mark missing telemetry as unknown, not benign.",
      "Assign the analyst and record the use-case SOP/version. Keep the case open while evidence or approval is pending."
    ],
    "investigation": [
      "Record source/destination IP, ports, signature, action, count and first/last seen. Distinguish blocked attempts from allowed traffic.",
      "Identify targeted DMZ services and whether a known authorized scanner generated the activity. Verify the scanner inventory and approved schedule.",
      "Review repeated sources, ports and signatures; correlate with web/application logs to identify successful access or exploitation.",
      "Use approved packet capture only where available and authorized. Assess whether legitimate business traffic was blocked."
    ],
    "escalation": "Allowed exploit traffic, corroborated compromise, persistent high-impact activity or disruption of a business service.",
    "response": [
      "Notify the shift lead/incident lead with affected assets, evidence, severity rationale and business impact. Follow the approved response/communication process.",
      "Request containment, account/session changes or blocking only through the authorized owner and procedure. This package executes no containment.",
      "Record actions, approval, timestamps and results; collect post-action evidence and monitor recurrence. Tuning/allowlisting requires documented scope, owner, expiry and review."
    ],
    "closure_requirement": "Record block effectiveness or benign explanation, affected services, monitoring results and linked response/change evidence.",
    "decisions": [
      "TRUE_POSITIVE: the detection represents a verified security incident; record corroborating evidence and response scope.",
      "FALSE_POSITIVE: the detection logic or interpretation was incorrect; document the contradiction and propose narrowly scoped tuning for lead review.",
      "BENIGN_AUTHORIZED: the observed behavior occurred and was approved; cite purpose, owner and approval. Do not label every authorized activity a false positive.",
      "AUTHORIZED_TEST: explicitly approved validation activity; record test scope and assessment source.",
      "DUPLICATE: link the active investigation and confirm ownership; do not discard new evidence.",
      "UNDETERMINED: insufficient evidence; record gaps and next actions, keep review open and escalate as appropriate."
    ],
    "gaps": [
      "The referenced IP-block checklist was not supplied.",
      "Existing source scanner allowlists and threat-platform names need local approval."
    ]
  },
  {
    "id": "DWP-SOP-004",
    "title": "Datacenter firewall blocked traffic",
    "category": "Network",
    "version": "1.0",
    "status": "DRAFT — lead approval and rule mapping pending",
    "source_file": "ES_Rules_SOP.xlsx",
    "source_sheet": "PA TRE",
    "source_trigger": "Source aggregates firewall detections by destination over 8 hours.",
    "telemetry": "Firewall threat/session logs, source/destination owners, application identity and change records.",
    "rule_ids": [],
    "triage": [
      "Open the Wazuh alert, record event ID, rule.id, rule.description, rule.level, timestamp, agent.name and raw event.",
      "Set an explicit investigation time range; confirm timezone and ingestion delay. Search related alerts and existing IRIS/Jira records.",
      "Identify asset owner/criticality and user; preserve original logs. Mark missing telemetry as unknown, not benign.",
      "Assign the analyst and record the use-case SOP/version. Keep the case open while evidence or approval is pending."
    ],
    "investigation": [
      "Capture source/destination assets, user, signature, ports, action and the correlated raw events.",
      "Validate source ownership, approved scanners and expected application flows against actual business requirements.",
      "Check for user-reported failures or service degradation matching the blocks.",
      "Correlate endpoint and server logs to separate malicious activity from a policy/configuration issue; request owner validation through the approved channel."
    ],
    "escalation": "Business-critical blocks, suspected compromise, unauthorized internal scanning or allowed malicious follow-on traffic.",
    "response": [
      "Notify the shift lead/incident lead with affected assets, evidence, severity rationale and business impact. Follow the approved response/communication process.",
      "Request containment, account/session changes or blocking only through the authorized owner and procedure. This package executes no containment.",
      "Record actions, approval, timestamps and results; collect post-action evidence and monitor recurrence. Tuning/allowlisting requires documented scope, owner, expiry and review."
    ],
    "closure_requirement": "Confirm the business service works or the malicious traffic remains contained; record the approved network-team action and follow-up.",
    "decisions": [
      "TRUE_POSITIVE: the detection represents a verified security incident; record corroborating evidence and response scope.",
      "FALSE_POSITIVE: the detection logic or interpretation was incorrect; document the contradiction and propose narrowly scoped tuning for lead review.",
      "BENIGN_AUTHORIZED: the observed behavior occurred and was approved; cite purpose, owner and approval. Do not label every authorized activity a false positive.",
      "AUTHORIZED_TEST: explicitly approved validation activity; record test scope and assessment source.",
      "DUPLICATE: link the active investigation and confirm ownership; do not discard new evidence.",
      "UNDETERMINED: insufficient evidence; record gaps and next actions, keep review open and escalate as appropriate."
    ],
    "gaps": [
      "Site names, scanner exceptions and owner-contact templates require local validation."
    ]
  },
  {
    "id": "DWP-SOP-005",
    "title": "New firewall threat signature",
    "category": "Network",
    "version": "1.0",
    "status": "DRAFT — lead approval and rule mapping pending",
    "source_file": "ES_Rules_SOP.xlsx",
    "source_sheet": "PA_new_sig",
    "source_trigger": "Source describes first-seen signatures; uniqueness behavior is not verified locally.",
    "telemetry": "Firewall signature metadata, software/content update history, action and traffic context.",
    "rule_ids": [],
    "triage": [
      "Open the Wazuh alert, record event ID, rule.id, rule.description, rule.level, timestamp, agent.name and raw event.",
      "Set an explicit investigation time range; confirm timezone and ingestion delay. Search related alerts and existing IRIS/Jira records.",
      "Identify asset owner/criticality and user; preserve original logs. Mark missing telemetry as unknown, not benign.",
      "Assign the analyst and record the use-case SOP/version. Keep the case open while evidence or approval is pending."
    ],
    "investigation": [
      "Record signature ID/name, action, source/destination, timestamp and the detection detail.",
      "Check whether the signature arrived with a recent content update or policy change; identify affected applications.",
      "Determine whether expected traffic was blocked or suspicious traffic allowed; corroborate with application/endpoint evidence.",
      "Ask the network/security owner to validate signature behavior and any proposed exception or policy change."
    ],
    "escalation": "Credible exploitation, allowed malicious traffic, unexpected widespread blocks or business impact.",
    "response": [
      "Notify the shift lead/incident lead with affected assets, evidence, severity rationale and business impact. Follow the approved response/communication process.",
      "Request containment, account/session changes or blocking only through the authorized owner and procedure. This package executes no containment.",
      "Record actions, approval, timestamps and results; collect post-action evidence and monitor recurrence. Tuning/allowlisting requires documented scope, owner, expiry and review."
    ],
    "closure_requirement": "Document the signature decision, owner review, approved configuration change if any and post-change monitoring.",
    "decisions": [
      "TRUE_POSITIVE: the detection represents a verified security incident; record corroborating evidence and response scope.",
      "FALSE_POSITIVE: the detection logic or interpretation was incorrect; document the contradiction and propose narrowly scoped tuning for lead review.",
      "BENIGN_AUTHORIZED: the observed behavior occurred and was approved; cite purpose, owner and approval. Do not label every authorized activity a false positive.",
      "AUTHORIZED_TEST: explicitly approved validation activity; record test scope and assessment source.",
      "DUPLICATE: link the active investigation and confirm ownership; do not discard new evidence.",
      "UNDETERMINED: insufficient evidence; record gaps and next actions, keep review open and escalate as appropriate."
    ],
    "gaps": [
      "Do not suppress a new signature solely because it recurs.",
      "First-seen correlation must be checked in the deployed detection."
    ]
  },
  {
    "id": "DWP-SOP-006",
    "title": "Suspicious scheduled task",
    "category": "Endpoint",
    "version": "1.0",
    "status": "DRAFT — lead approval and rule mapping pending",
    "source_file": "ES_Rules_SOP.xlsx",
    "source_sheet": "Scheduled_Task",
    "source_trigger": "Source alerts on scheduled-task creation; source exceptions are unverified.",
    "telemetry": "Task Scheduler/Security logs and endpoint process/file telemetry; command line and task definition where available.",
    "rule_ids": [],
    "triage": [
      "Open the Wazuh alert, record event ID, rule.id, rule.description, rule.level, timestamp, agent.name and raw event.",
      "Set an explicit investigation time range; confirm timezone and ingestion delay. Search related alerts and existing IRIS/Jira records.",
      "Identify asset owner/criticality and user; preserve original logs. Mark missing telemetry as unknown, not benign.",
      "Assign the analyst and record the use-case SOP/version. Keep the case open while evidence or approval is pending."
    ],
    "investigation": [
      "Record task name, creator, principal, trigger, executable/script, arguments and creation/update time.",
      "Trace the creating process and parent; inspect file path, signature and hash without executing the payload.",
      "Compare with approved software deployment and maintenance requests; validate identity, scope and timing rather than relying only on a ticket number.",
      "Search for other tasks, executions, related network activity and the same artifact on other hosts."
    ],
    "escalation": "Unauthorized persistence, suspicious execution chain, malicious file evidence or lateral spread.",
    "response": [
      "Notify the shift lead/incident lead with affected assets, evidence, severity rationale and business impact. Follow the approved response/communication process.",
      "Request containment, account/session changes or blocking only through the authorized owner and procedure. This package executes no containment.",
      "Record actions, approval, timestamps and results; collect post-action evidence and monitor recurrence. Tuning/allowlisting requires documented scope, owner, expiry and review."
    ],
    "closure_requirement": "Document the authorized purpose or approved removal/remediation, affected assets and absence of unwanted executions during follow-up.",
    "decisions": [
      "TRUE_POSITIVE: the detection represents a verified security incident; record corroborating evidence and response scope.",
      "FALSE_POSITIVE: the detection logic or interpretation was incorrect; document the contradiction and propose narrowly scoped tuning for lead review.",
      "BENIGN_AUTHORIZED: the observed behavior occurred and was approved; cite purpose, owner and approval. Do not label every authorized activity a false positive.",
      "AUTHORIZED_TEST: explicitly approved validation activity; record test scope and assessment source.",
      "DUPLICATE: link the active investigation and confirm ownership; do not discard new evidence.",
      "UNDETERMINED: insufficient evidence; record gaps and next actions, keep review open and escalate as appropriate."
    ],
    "gaps": [
      "Malware response checklist was referenced but not supplied."
    ]
  },
  {
    "id": "DWP-SOP-007",
    "title": "Increase in intrusion events",
    "category": "Network",
    "version": "1.0",
    "status": "DRAFT — lead approval and rule mapping pending",
    "source_file": "ES_Rules_SOP.xlsx",
    "source_sheet": "Substantial_increase",
    "source_trigger": "Source identifies abnormal growth in firewall detection/signature counts; no numeric baseline is supplied.",
    "telemetry": "Comparable firewall time windows, session/threat logs, internal asset mapping and approved scan/change records.",
    "rule_ids": [],
    "triage": [
      "Open the Wazuh alert, record event ID, rule.id, rule.description, rule.level, timestamp, agent.name and raw event.",
      "Set an explicit investigation time range; confirm timezone and ingestion delay. Search related alerts and existing IRIS/Jira records.",
      "Identify asset owner/criticality and user; preserve original logs. Mark missing telemetry as unknown, not benign.",
      "Assign the analyst and record the use-case SOP/version. Keep the case open while evidence or approval is pending."
    ],
    "investigation": [
      "Compare the current count and rate with an appropriate historical window, controlling for log duplication and ingestion changes.",
      "Break down sources, destinations, ports, applications, signatures and actions.",
      "Identify broad scanning versus a single noisy service; check approved scanners and changes.",
      "Correlate internal-source behavior with endpoint activity and assess successful connections, compromise and business impact."
    ],
    "escalation": "Unauthorized scanning, internal compromise, credible exploitation or material impact.",
    "response": [
      "Notify the shift lead/incident lead with affected assets, evidence, severity rationale and business impact. Follow the approved response/communication process.",
      "Request containment, account/session changes or blocking only through the authorized owner and procedure. This package executes no containment.",
      "Record actions, approval, timestamps and results; collect post-action evidence and monitor recurrence. Tuning/allowlisting requires documented scope, owner, expiry and review."
    ],
    "closure_requirement": "Record the cause of the increase, affected scope, approved action and normalized trend or a documented benign explanation.",
    "decisions": [
      "TRUE_POSITIVE: the detection represents a verified security incident; record corroborating evidence and response scope.",
      "FALSE_POSITIVE: the detection logic or interpretation was incorrect; document the contradiction and propose narrowly scoped tuning for lead review.",
      "BENIGN_AUTHORIZED: the observed behavior occurred and was approved; cite purpose, owner and approval. Do not label every authorized activity a false positive.",
      "AUTHORIZED_TEST: explicitly approved validation activity; record test scope and assessment source.",
      "DUPLICATE: link the active investigation and confirm ownership; do not discard new evidence.",
      "UNDETERMINED: insufficient evidence; record gaps and next actions, keep review open and escalate as appropriate."
    ],
    "gaps": [
      "Guest-network and scanner exclusions from the source are not automatically adopted.",
      "Baseline and trigger must be defined and tested locally."
    ]
  },
  {
    "id": "DWP-SOP-008",
    "title": "Short-lived account",
    "category": "Identity",
    "version": "1.0",
    "status": "DRAFT — lead approval and rule mapping pending",
    "source_file": "ES_Rules_SOP.xlsx",
    "source_sheet": "Shortlived",
    "source_trigger": "Source describes an account created and deleted within 24 hours.",
    "telemetry": "Identity/account lifecycle logs with account SID or equivalent stable identifier, actor and audit timestamps.",
    "rule_ids": [],
    "triage": [
      "Open the Wazuh alert, record event ID, rule.id, rule.description, rule.level, timestamp, agent.name and raw event.",
      "Set an explicit investigation time range; confirm timezone and ingestion delay. Search related alerts and existing IRIS/Jira records.",
      "Identify asset owner/criticality and user; preserve original logs. Mark missing telemetry as unknown, not benign.",
      "Assign the analyst and record the use-case SOP/version. Keep the case open while evidence or approval is pending."
    ],
    "investigation": [
      "Link create/delete events using the same account identifier and validate ordering and time zone.",
      "Identify who performed each operation, originating host and account privileges/group membership.",
      "Search for logons, privilege changes and other activity between creation and deletion.",
      "Validate an approved provisioning/testing request and owner confirmation; inspect other accounts created by the same actor."
    ],
    "escalation": "Unapproved lifecycle activity, privileged access, suspicious sessions or an actor inconsistent with the approved request.",
    "response": [
      "Notify the shift lead/incident lead with affected assets, evidence, severity rationale and business impact. Follow the approved response/communication process.",
      "Request containment, account/session changes or blocking only through the authorized owner and procedure. This package executes no containment.",
      "Record actions, approval, timestamps and results; collect post-action evidence and monitor recurrence. Tuning/allowlisting requires documented scope, owner, expiry and review."
    ],
    "closure_requirement": "Record the account timeline and verified purpose, or response outcome for every affected identity and session.",
    "decisions": [
      "TRUE_POSITIVE: the detection represents a verified security incident; record corroborating evidence and response scope.",
      "FALSE_POSITIVE: the detection logic or interpretation was incorrect; document the contradiction and propose narrowly scoped tuning for lead review.",
      "BENIGN_AUTHORIZED: the observed behavior occurred and was approved; cite purpose, owner and approval. Do not label every authorized activity a false positive.",
      "AUTHORIZED_TEST: explicitly approved validation activity; record test scope and assessment source.",
      "DUPLICATE: link the active investigation and confirm ownership; do not discard new evidence.",
      "UNDETERMINED: insufficient evidence; record gaps and next actions, keep review open and escalate as appropriate."
    ],
    "gaps": [
      "Source 24-hour correlation is not a verified installed rule."
    ]
  },
  {
    "id": "DWP-SOP-009",
    "title": "Untriaged alert backlog",
    "category": "Operations",
    "version": "1.0",
    "status": "DRAFT — lead approval and rule mapping pending",
    "source_file": "ES_Rules_SOP.xlsx",
    "source_sheet": "Notable_Evnts",
    "source_trigger": "Source flags unhandled Medium/High/Critical events after 4 hours.",
    "telemetry": "A triage system with assignment, severity, status and acknowledgment timestamps; Wazuh event timestamps alone are insufficient.",
    "rule_ids": [],
    "triage": [
      "Open the Wazuh alert, record event ID, rule.id, rule.description, rule.level, timestamp, agent.name and raw event.",
      "Set an explicit investigation time range; confirm timezone and ingestion delay. Search related alerts and existing IRIS/Jira records.",
      "Identify asset owner/criticality and user; preserve original logs. Mark missing telemetry as unknown, not benign.",
      "Assign the analyst and record the use-case SOP/version. Keep the case open while evidence or approval is pending."
    ],
    "investigation": [
      "Find the original alert and verify creation time, current owner and whether triage already occurred in IRIS/Jira.",
      "Distinguish notification delay, ingestion delay, duplicate events and genuinely missed work.",
      "Assign unhandled items, notify the shift lead and investigate using each underlying use-case SOP.",
      "Document staffing, routing or processing failure; reconcile backlog counts after the review."
    ],
    "escalation": "Unowned high-impact alerts, breached locally agreed response targets or a recurring routing failure.",
    "response": [
      "Notify the shift lead/incident lead with affected assets, evidence, severity rationale and business impact. Follow the approved response/communication process.",
      "Request containment, account/session changes or blocking only through the authorized owner and procedure. This package executes no containment.",
      "Record actions, approval, timestamps and results; collect post-action evidence and monitor recurrence. Tuning/allowlisting requires documented scope, owner, expiry and review."
    ],
    "closure_requirement": "Confirm every missed item has an owner and completed triage or a documented escalation; link the original case rather than hiding backlog.",
    "decisions": [
      "TRUE_POSITIVE: the detection represents a verified security incident; record corroborating evidence and response scope.",
      "FALSE_POSITIVE: the detection logic or interpretation was incorrect; document the contradiction and propose narrowly scoped tuning for lead review.",
      "BENIGN_AUTHORIZED: the observed behavior occurred and was approved; cite purpose, owner and approval. Do not label every authorized activity a false positive.",
      "AUTHORIZED_TEST: explicitly approved validation activity; record test scope and assessment source.",
      "DUPLICATE: link the active investigation and confirm ownership; do not discard new evidence.",
      "UNDETERMINED: insufficient evidence; record gaps and next actions, keep review open and escalate as appropriate."
    ],
    "gaps": [
      "Source four-hour target is not an agreed SLA.",
      "Do not infer acknowledgment or closed status from a Wazuh indexed event."
    ]
  },
  {
    "id": "DWP-SOP-010",
    "title": "High outbound traffic volume",
    "category": "Network",
    "version": "1.0",
    "status": "DRAFT — lead approval and rule mapping pending",
    "source_file": "ES_Rules_SOP.xlsx",
    "source_sheet": "High_Vol",
    "source_trigger": "Source describes outbound traffic above 1 GB; aggregation window is not specified.",
    "telemetry": "Firewall/proxy/flow byte counters, destination/app identity and host/process/user context.",
    "rule_ids": [],
    "triage": [
      "Open the Wazuh alert, record event ID, rule.id, rule.description, rule.level, timestamp, agent.name and raw event.",
      "Set an explicit investigation time range; confirm timezone and ingestion delay. Search related alerts and existing IRIS/Jira records.",
      "Identify asset owner/criticality and user; preserve original logs. Mark missing telemetry as unknown, not benign.",
      "Assign the analyst and record the use-case SOP/version. Keep the case open while evidence or approval is pending."
    ],
    "investigation": [
      "Confirm transmitted bytes, units, aggregation window and whether counters are duplicated or cumulative.",
      "Identify destination, application, process, user and business purpose; compare against baseline.",
      "Determine the data category and whether sensitive information may have left the organization; use approved evidence collection.",
      "Correlate endpoint activity, downloads, archive creation and authentication. Verify cloud-app exceptions with the data owner and current policy."
    ],
    "escalation": "Suspected exfiltration, unapproved cloud transfer, malware-related traffic or policy breach involving sensitive data.",
    "response": [
      "Notify the shift lead/incident lead with affected assets, evidence, severity rationale and business impact. Follow the approved response/communication process.",
      "Request containment, account/session changes or blocking only through the authorized owner and procedure. This package executes no containment.",
      "Record actions, approval, timestamps and results; collect post-action evidence and monitor recurrence. Tuning/allowlisting requires documented scope, owner, expiry and review."
    ],
    "closure_requirement": "Document transfer purpose and authorization or containment/remediation, data-impact assessment and follow-up monitoring.",
    "decisions": [
      "TRUE_POSITIVE: the detection represents a verified security incident; record corroborating evidence and response scope.",
      "FALSE_POSITIVE: the detection logic or interpretation was incorrect; document the contradiction and propose narrowly scoped tuning for lead review.",
      "BENIGN_AUTHORIZED: the observed behavior occurred and was approved; cite purpose, owner and approval. Do not label every authorized activity a false positive.",
      "AUTHORIZED_TEST: explicitly approved validation activity; record test scope and assessment source.",
      "DUPLICATE: link the active investigation and confirm ownership; do not discard new evidence.",
      "UNDETERMINED: insufficient evidence; record gaps and next actions, keep review open and escalate as appropriate."
    ],
    "gaps": [
      "Source cloud-service and business-unit exceptions must not be treated as local policy.",
      "An approved app or URL alone does not prove a transfer is safe.",
      "Aggregation window and units require local detection validation."
    ]
  },
  {
    "id": "DWP-SOP-011",
    "title": "Excessive DNS queries",
    "category": "Network",
    "version": "1.0",
    "status": "DRAFT — lead approval and rule mapping pending",
    "source_file": "ES_Rules_SOP.xlsx",
    "source_sheet": "DNS query",
    "source_trigger": "Source describes more than 500 DNS queries per host per hour.",
    "telemetry": "DNS query/response logs with client identity, timestamps, queried name and response code; endpoint process correlation where available.",
    "rule_ids": [],
    "triage": [
      "Open the Wazuh alert, record event ID, rule.id, rule.description, rule.level, timestamp, agent.name and raw event.",
      "Set an explicit investigation time range; confirm timezone and ingestion delay. Search related alerts and existing IRIS/Jira records.",
      "Identify asset owner/criticality and user; preserve original logs. Mark missing telemetry as unknown, not benign.",
      "Assign the analyst and record the use-case SOP/version. Keep the case open while evidence or approval is pending."
    ],
    "investigation": [
      "Recount queries per client within one hour and check retries, caching behavior and logging duplication.",
      "Review queried names, unique subdomains, label length, response codes and periodicity.",
      "Identify the generating process/application; compare updates, configuration faults and normal business behavior.",
      "Correlate suspicious domains with OpenCTI and endpoint/network evidence; an observable match alone is not a malicious verdict."
    ],
    "escalation": "Suspected DNS tunneling, command-and-control, suspicious process association or malware corroboration.",
    "response": [
      "Notify the shift lead/incident lead with affected assets, evidence, severity rationale and business impact. Follow the approved response/communication process.",
      "Request containment, account/session changes or blocking only through the authorized owner and procedure. This package executes no containment.",
      "Record actions, approval, timestamps and results; collect post-action evidence and monitor recurrence. Tuning/allowlisting requires documented scope, owner, expiry and review."
    ],
    "closure_requirement": "Document the benign cause or approved remediation and verified reduction/cessation during the agreed observation period.",
    "decisions": [
      "TRUE_POSITIVE: the detection represents a verified security incident; record corroborating evidence and response scope.",
      "FALSE_POSITIVE: the detection logic or interpretation was incorrect; document the contradiction and propose narrowly scoped tuning for lead review.",
      "BENIGN_AUTHORIZED: the observed behavior occurred and was approved; cite purpose, owner and approval. Do not label every authorized activity a false positive.",
      "AUTHORIZED_TEST: explicitly approved validation activity; record test scope and assessment source.",
      "DUPLICATE: link the active investigation and confirm ownership; do not discard new evidence.",
      "UNDETERMINED: insufficient evidence; record gaps and next actions, keep review open and escalate as appropriate."
    ],
    "gaps": [
      "The source wildcard/domain exclusions are ambiguous and are not adopted.",
      "DNS telemetry and per-host correlation are prerequisites."
    ]
  },
  {
    "id": "DWP-SOP-012",
    "title": "Excessive failed logins",
    "category": "Identity",
    "version": "1.0",
    "status": "DRAFT — lead approval and rule mapping pending",
    "source_file": "ES_Rules_SOP.xlsx",
    "source_sheet": "Excessive Failed",
    "source_trigger": "Source describes more than 15 failed logons per account; no time window is supplied.",
    "telemetry": "Authentication logs, result/failure codes, logon type, actor/source and identity inventory.",
    "rule_ids": [],
    "triage": [
      "Open the Wazuh alert, record event ID, rule.id, rule.description, rule.level, timestamp, agent.name and raw event.",
      "Set an explicit investigation time range; confirm timezone and ingestion delay. Search related alerts and existing IRIS/Jira records.",
      "Identify asset owner/criticality and user; preserve original logs. Mark missing telemetry as unknown, not benign.",
      "Assign the analyst and record the use-case SOP/version. Keep the case open while evidence or approval is pending."
    ],
    "investigation": [
      "Validate failure counts, time window, target identities, source IP/host and failure reasons.",
      "Distinguish interactive sessions, stale service credentials and scheduled tasks; do not assume an interactive logon was the legitimate account owner.",
      "Check successful logons and privilege changes after failures; search for multiple targets/sources indicating spraying or brute force.",
      "Validate helpdesk/password-reset activity with the owner and request scope; preserve evidence of any suspicious successful access."
    ],
    "escalation": "Suspicious success after failures, privileged-account targeting, password spraying or unapproved source activity.",
    "response": [
      "Notify the shift lead/incident lead with affected assets, evidence, severity rationale and business impact. Follow the approved response/communication process.",
      "Request containment, account/session changes or blocking only through the authorized owner and procedure. This package executes no containment.",
      "Record actions, approval, timestamps and results; collect post-action evidence and monitor recurrence. Tuning/allowlisting requires documented scope, owner, expiry and review."
    ],
    "closure_requirement": "Record the verified cause and recovery, affected identities/sessions and follow-up authentication results.",
    "decisions": [
      "TRUE_POSITIVE: the detection represents a verified security incident; record corroborating evidence and response scope.",
      "FALSE_POSITIVE: the detection logic or interpretation was incorrect; document the contradiction and propose narrowly scoped tuning for lead review.",
      "BENIGN_AUTHORIZED: the observed behavior occurred and was approved; cite purpose, owner and approval. Do not label every authorized activity a false positive.",
      "AUTHORIZED_TEST: explicitly approved validation activity; record test scope and assessment source.",
      "DUPLICATE: link the active investigation and confirm ownership; do not discard new evidence.",
      "UNDETERMINED: insufficient evidence; record gaps and next actions, keep review open and escalate as appropriate."
    ],
    "gaps": [
      "The time window and correlation must be defined locally.",
      "Interactive/noninteractive logon type alone does not establish legitimacy."
    ]
  },
  {
    "id": "DWP-SOP-013",
    "title": "Audit log tampering",
    "category": "Endpoint",
    "version": "1.0",
    "status": "DRAFT — lead approval and rule mapping pending",
    "source_file": "ES_Rules_SOP.xlsx",
    "source_sheet": "Audit_activity",
    "source_trigger": "Source covers audit-log clearing, deletion or modification on servers/VMs.",
    "telemetry": "Security/audit logs, event collector health, process/user context and authorized maintenance records.",
    "rule_ids": [],
    "triage": [
      "Open the Wazuh alert, record event ID, rule.id, rule.description, rule.level, timestamp, agent.name and raw event.",
      "Set an explicit investigation time range; confirm timezone and ingestion delay. Search related alerts and existing IRIS/Jira records.",
      "Identify asset owner/criticality and user; preserve original logs. Mark missing telemetry as unknown, not benign.",
      "Assign the analyst and record the use-case SOP/version. Keep the case open while evidence or approval is pending."
    ],
    "investigation": [
      "Record host, actor, event ID, time and the affected audit source; preserve remaining evidence immediately.",
      "Differentiate explicit clearing/deletion from retention, rotation, forwarding outage or permission failure.",
      "Correlate the responsible process and surrounding logons, privilege changes and suspicious commands.",
      "Validate maintenance scope and actor; check whether telemetry loss conceals other activity."
    ],
    "escalation": "Unapproved clearing, suspicious privileged activity, continued loss of audit visibility or evidence of compromise.",
    "response": [
      "Notify the shift lead/incident lead with affected assets, evidence, severity rationale and business impact. Follow the approved response/communication process.",
      "Request containment, account/session changes or blocking only through the authorized owner and procedure. This package executes no containment.",
      "Record actions, approval, timestamps and results; collect post-action evidence and monitor recurrence. Tuning/allowlisting requires documented scope, owner, expiry and review."
    ],
    "closure_requirement": "Document the reason, preservation work and restoration of logging; corroborate the timeline using independent sources.",
    "decisions": [
      "TRUE_POSITIVE: the detection represents a verified security incident; record corroborating evidence and response scope.",
      "FALSE_POSITIVE: the detection logic or interpretation was incorrect; document the contradiction and propose narrowly scoped tuning for lead review.",
      "BENIGN_AUTHORIZED: the observed behavior occurred and was approved; cite purpose, owner and approval. Do not label every authorized activity a false positive.",
      "AUTHORIZED_TEST: explicitly approved validation activity; record test scope and assessment source.",
      "DUPLICATE: link the active investigation and confirm ownership; do not discard new evidence.",
      "UNDETERMINED: insufficient evidence; record gaps and next actions, keep review open and escalate as appropriate."
    ],
    "gaps": [
      "A maintenance ticket alone is not sufficient closure evidence."
    ]
  },
  {
    "id": "DWP-SOP-014",
    "title": "Shadow-copy deletion or resizing",
    "category": "Endpoint",
    "version": "1.0",
    "status": "DRAFT — lead approval and rule mapping pending",
    "source_file": "ES_Rules_SOP.xlsx",
    "source_sheet": "Volume Shadow",
    "source_trigger": "Source title says creation, but its detection description concerns vssadmin deletion/resizing.",
    "telemetry": "Endpoint process creation with full command line, user/parent context, backup status and related file activity.",
    "rule_ids": [],
    "triage": [
      "Open the Wazuh alert, record event ID, rule.id, rule.description, rule.level, timestamp, agent.name and raw event.",
      "Set an explicit investigation time range; confirm timezone and ingestion delay. Search related alerts and existing IRIS/Jira records.",
      "Identify asset owner/criticality and user; preserve original logs. Mark missing telemetry as unknown, not benign.",
      "Assign the analyst and record the use-case SOP/version. Keep the case open while evidence or approval is pending."
    ],
    "investigation": [
      "Read the complete command and distinguish harmless listing from deletion or storage resizing. Preserve it as text; do not execute it.",
      "Identify actor, parent process, executable signature/hash and any approved backup/maintenance change.",
      "Look for encryption, ransom notes, backup disruption and similar activity on other hosts.",
      "Check backup/recovery impact with the backup owner and prioritize active ransomware evidence."
    ],
    "escalation": "Unauthorized destructive command, ransomware evidence, impaired recovery or widespread activity.",
    "response": [
      "Notify the shift lead/incident lead with affected assets, evidence, severity rationale and business impact. Follow the approved response/communication process.",
      "Request containment, account/session changes or blocking only through the authorized owner and procedure. This package executes no containment.",
      "Record actions, approval, timestamps and results; collect post-action evidence and monitor recurrence. Tuning/allowlisting requires documented scope, owner, expiry and review."
    ],
    "closure_requirement": "Confirm approved purpose or response outcome and validate backup/recovery availability with its owner.",
    "decisions": [
      "TRUE_POSITIVE: the detection represents a verified security incident; record corroborating evidence and response scope.",
      "FALSE_POSITIVE: the detection logic or interpretation was incorrect; document the contradiction and propose narrowly scoped tuning for lead review.",
      "BENIGN_AUTHORIZED: the observed behavior occurred and was approved; cite purpose, owner and approval. Do not label every authorized activity a false positive.",
      "AUTHORIZED_TEST: explicitly approved validation activity; record test scope and assessment source.",
      "DUPLICATE: link the active investigation and confirm ownership; do not discard new evidence.",
      "UNDETERMINED: insufficient evidence; record gaps and next actions, keep review open and escalate as appropriate."
    ],
    "gaps": [
      "The source title/behavior mismatch is explicitly corrected in this adaptation.",
      "Malware remediation and backup recovery procedures were not supplied."
    ]
  },
  {
    "id": "DWP-SOP-015",
    "title": "VIP or critical-account activity",
    "category": "Identity",
    "version": "1.0",
    "status": "DRAFT — lead approval and rule mapping pending",
    "source_file": "ES_Rules_SOP.xlsx",
    "source_sheet": "VIP activity",
    "source_trigger": "Source describes lockout, deletion or disabling of listed VIP accounts.",
    "telemetry": "Approved critical-account inventory, account-change and authentication logs, owner and lifecycle requests.",
    "rule_ids": [],
    "triage": [
      "Open the Wazuh alert, record event ID, rule.id, rule.description, rule.level, timestamp, agent.name and raw event.",
      "Set an explicit investigation time range; confirm timezone and ingestion delay. Search related alerts and existing IRIS/Jira records.",
      "Identify asset owner/criticality and user; preserve original logs. Mark missing telemetry as unknown, not benign.",
      "Assign the analyst and record the use-case SOP/version. Keep the case open while evidence or approval is pending."
    ],
    "investigation": [
      "Verify the target against the approved critical-account inventory; record actor, host, event and time.",
      "Correlate lockout/deletion/disablement with failed/successful logons, privileges and recent changes.",
      "Validate request scope, identity and owner confirmation; determine service/user impact.",
      "Investigate related accounts and actors and notify the shift lead for suspicious or disruptive changes."
    ],
    "escalation": "Unauthorized account changes, possible takeover, privileged misuse or disruption of a critical identity.",
    "response": [
      "Notify the shift lead/incident lead with affected assets, evidence, severity rationale and business impact. Follow the approved response/communication process.",
      "Request containment, account/session changes or blocking only through the authorized owner and procedure. This package executes no containment.",
      "Record actions, approval, timestamps and results; collect post-action evidence and monitor recurrence. Tuning/allowlisting requires documented scope, owner, expiry and review."
    ],
    "closure_requirement": "Document account state, approved purpose or remediation and owner-confirmed recovery with follow-up results.",
    "decisions": [
      "TRUE_POSITIVE: the detection represents a verified security incident; record corroborating evidence and response scope.",
      "FALSE_POSITIVE: the detection logic or interpretation was incorrect; document the contradiction and propose narrowly scoped tuning for lead review.",
      "BENIGN_AUTHORIZED: the observed behavior occurred and was approved; cite purpose, owner and approval. Do not label every authorized activity a false positive.",
      "AUTHORIZED_TEST: explicitly approved validation activity; record test scope and assessment source.",
      "DUPLICATE: link the active investigation and confirm ownership; do not discard new evidence.",
      "UNDETERMINED: insufficient evidence; record gaps and next actions, keep review open and escalate as appropriate."
    ],
    "gaps": [
      "The original identity feed/KV-store mechanism is not available in the supplied material."
    ]
  },
  {
    "id": "DWP-SOP-016",
    "title": "Suspicious shell reaching the internet",
    "category": "Endpoint",
    "version": "1.0",
    "status": "DRAFT — lead approval and rule mapping pending",
    "source_file": "WBG Suspicious Shell reaching Internet.xlsx",
    "source_sheet": "Suspicious shell reaching inter",
    "source_trigger": "Source describes a shell/script initiating an internet HTTP request.",
    "telemetry": "Process creation/parent/command-line logs plus correlated network/DNS/proxy telemetry.",
    "rule_ids": [],
    "triage": [
      "Open the Wazuh alert, record event ID, rule.id, rule.description, rule.level, timestamp, agent.name and raw event.",
      "Set an explicit investigation time range; confirm timezone and ingestion delay. Search related alerts and existing IRIS/Jira records.",
      "Identify asset owner/criticality and user; preserve original logs. Mark missing telemetry as unknown, not benign.",
      "Assign the analyst and record the use-case SOP/version. Keep the case open while evidence or approval is pending."
    ],
    "investigation": [
      "Record host, user, process/parent, command line, script/file path and time. Preserve script text without running it.",
      "Correlate destination IP/domain/URL, port, action and connection outcome with the same process where telemetry permits.",
      "Check hashes/signatures and OpenCTI context, then compare with approved scripts, updates and automation.",
      "Look for downloads, encoded commands, child processes, persistence and repeated connections; search other affected hosts."
    ],
    "escalation": "Suspicious execution plus network evidence, malicious payload corroboration, persistence or credential/data access.",
    "response": [
      "Notify the shift lead/incident lead with affected assets, evidence, severity rationale and business impact. Follow the approved response/communication process.",
      "Request containment, account/session changes or blocking only through the authorized owner and procedure. This package executes no containment.",
      "Record actions, approval, timestamps and results; collect post-action evidence and monitor recurrence. Tuning/allowlisting requires documented scope, owner, expiry and review."
    ],
    "closure_requirement": "Document the verified authorized script or remediation, impacted scope and observed absence of unwanted activity during follow-up.",
    "decisions": [
      "TRUE_POSITIVE: the detection represents a verified security incident; record corroborating evidence and response scope.",
      "FALSE_POSITIVE: the detection logic or interpretation was incorrect; document the contradiction and propose narrowly scoped tuning for lead review.",
      "BENIGN_AUTHORIZED: the observed behavior occurred and was approved; cite purpose, owner and approval. Do not label every authorized activity a false positive.",
      "AUTHORIZED_TEST: explicitly approved validation activity; record test scope and assessment source.",
      "DUPLICATE: link the active investigation and confirm ownership; do not discard new evidence.",
      "UNDETERMINED: insufficient evidence; record gaps and next actions, keep review open and escalate as appropriate."
    ],
    "gaps": [
      "Process logs alone do not prove a successful network connection.",
      "Malware checklist was referenced but not supplied."
    ]
  },
  {
    "id": "DWP-SOP-017",
    "title": "Phishing page detected",
    "category": "Network",
    "version": "1.0",
    "status": "DRAFT — lead approval and rule mapping pending",
    "source_file": "WBG Suspicious Shell reaching Internet.xlsx",
    "source_sheet": "Phishing page detected",
    "source_trigger": "Source describes a firewall phishing-page detection.",
    "telemetry": "URL/threat/proxy logs with action, user/client mapping and approved URL-analysis tooling.",
    "rule_ids": [],
    "triage": [
      "Open the Wazuh alert, record event ID, rule.id, rule.description, rule.level, timestamp, agent.name and raw event.",
      "Set an explicit investigation time range; confirm timezone and ingestion delay. Search related alerts and existing IRIS/Jira records.",
      "Identify asset owner/criticality and user; preserve original logs. Mark missing telemetry as unknown, not benign.",
      "Assign the analyst and record the use-case SOP/version. Keep the case open while evidence or approval is pending."
    ],
    "investigation": [
      "Record the URL as evidence, source/destination, user, timestamp, detection and allow/block action.",
      "Determine whether the user reached the page or was blocked; check relevant proxy/browser/identity records where authorized.",
      "Analyze through approved isolated tooling and existing intelligence; do not open the suspect URL in a production analyst browser.",
      "Determine whether credentials were entered or a file downloaded; correlate identity sessions and endpoint activity."
    ],
    "escalation": "Credential submission, malicious download, suspicious follow-on login or confirmed user exposure.",
    "response": [
      "Notify the shift lead/incident lead with affected assets, evidence, severity rationale and business impact. Follow the approved response/communication process.",
      "Request containment, account/session changes or blocking only through the authorized owner and procedure. This package executes no containment.",
      "Record actions, approval, timestamps and results; collect post-action evidence and monitor recurrence. Tuning/allowlisting requires documented scope, owner, expiry and review."
    ],
    "closure_requirement": "Document exposure and verdict, any credential/session remediation, owner notification and follow-up results.",
    "decisions": [
      "TRUE_POSITIVE: the detection represents a verified security incident; record corroborating evidence and response scope.",
      "FALSE_POSITIVE: the detection logic or interpretation was incorrect; document the contradiction and propose narrowly scoped tuning for lead review.",
      "BENIGN_AUTHORIZED: the observed behavior occurred and was approved; cite purpose, owner and approval. Do not label every authorized activity a false positive.",
      "AUTHORIZED_TEST: explicitly approved validation activity; record test scope and assessment source.",
      "DUPLICATE: link the active investigation and confirm ownership; do not discard new evidence.",
      "UNDETERMINED: insufficient evidence; record gaps and next actions, keep review open and escalate as appropriate."
    ],
    "gaps": [
      "The referenced phishing checklist was not supplied.",
      "A page unavailable at investigation time does not by itself establish false positive."
    ]
  }
]});