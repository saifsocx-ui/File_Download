export function mount(root: HTMLElement, http: any) {
  let disposed = false;
  const el = (tag: string, text = '', cls = '') => { const n = document.createElement(tag); n.textContent = text; n.className = cls; return n; };
  const shell = el('div', '', 'socPlaybooks'); root.append(shell);
  const header = el('header'); header.append(el('span','WAZUH · SOC OPERATIONS','eyebrow'),el('h1','Investigation playbooks'),el('p','Find the use case. Follow the evidence. Document your decision.')); shell.append(header);
  const status = el('p','Loading protected catalogue…'); shell.append(status);
  const state = new Map<string, {checks: Set<string>, notes: string, verdict: string}>();
  const draw = (data: any[]) => {
    status.remove();
    const metrics = el('div','','metrics');
    for(const [v,label] of [[data.length,'Investigation guides'],[new Set(data.map(p=>p.category)).size,'Security domains'],[data.filter(p=>p.rule_ids.length).length,'Mapped rules']]) { const c=el('div');c.append(el('strong',String(v)),el('span',String(label)));metrics.append(c); } shell.append(metrics);
    const controls=el('div','','controls'); const search=el('input') as HTMLInputElement;search.type='search'; search.placeholder='Search ES use case, rule ID or technique';search.setAttribute('aria-label','Search playbooks');
    const filter=el('select') as HTMLSelectElement;filter.setAttribute('aria-label','Security domain');
    for(const c of ['',...Array.from(new Set(data.map(p=>p.category))).sort()]) {const o=el('option',c || 'All security domains') as HTMLOptionElement;o.value=c;filter.append(o);}
    controls.append(search,filter);shell.append(controls);
    const body=el('div','','layout'),list=el('nav','','catalogue'),detail=el('article','','detail'); list.setAttribute('aria-label','ES use cases');body.append(list,detail);shell.append(body);
    let selected=data[0]?.id;
    const show=(p:any)=>{
      selected=p.id;detail.replaceChildren(); let s=state.get(p.id);if(!s){s={checks:new Set(),notes:'',verdict:'UNDETERMINED'};state.set(p.id,s);} const current=s;
      detail.append(el('span',p.id+' · '+p.category,'eyebrow'),el('h2',p.title),el('p',p.status,'badge'));
      const section=(title:string, items:string[],check=false)=>{const box=el('section');box.append(el('h3',title));items.forEach((text,i)=>{if(check){const label=el('label','','step'),input=el('input') as HTMLInputElement;input.type='checkbox';const key=title+i;input.checked=current.checks.has(key);input.onchange=()=>{input.checked?current.checks.add(key):current.checks.delete(key);};label.append(input,el('span',text));box.append(label);}else box.append(el('p',text));});detail.append(box);};
      section('Detection & ES rule reference',[p.source_trigger,'Telemetry: '+p.telemetry,'Source: '+p.source_file+' / '+p.source_sheet,'Wazuh rule IDs: '+(p.rule_ids.join(', ')||'Mapping pending — detection coverage not verified')]);
      section('1 · Initial triage',p.triage,true);section('2 · Investigate',p.investigation,true);section('3 · Escalate & respond',[p.escalation,...p.response],true);section('4 · Closure criteria',[p.closure_requirement,...p.decisions]);section('Review gaps',p.gaps);
      const closure=el('section');closure.append(el('h3','Investigation record · session draft'));
      const verdict=el('select') as HTMLSelectElement;verdict.setAttribute('aria-label','Verdict');for(const v of ['UNDETERMINED','TRUE_POSITIVE','FALSE_POSITIVE','BENIGN_AUTHORIZED','AUTHORIZED_TEST','DUPLICATE']){const o=el('option',v) as HTMLOptionElement;o.value=v;verdict.append(o);} verdict.value=current.verdict;verdict.onchange=()=>current.verdict=verdict.value;
      const notes=el('textarea') as HTMLTextAreaElement;notes.setAttribute('aria-label','Evidence and closure notes');notes.placeholder='Alert/case ID, host/user, time window, evidence, rationale, approved actions, outcome, reviewer and remaining gaps…';notes.value=current.notes;notes.oninput=()=>current.notes=notes.value;
      const exportButton=el('button','Download investigation draft');exportButton.onclick=()=>{const text=['# '+p.title,p.id+' / version '+p.version,'Verdict: '+current.verdict,'Checked steps: '+current.checks.size,'Evidence and closure notes:',current.notes,'Draft only. Record evidence and obtain required review in IRIS/Jira.'].join('\n\n');const url=URL.createObjectURL(new Blob([text],{type:'text/plain'}));const a=el('a') as HTMLAnchorElement;a.href=url;a.download=p.id+'-investigation.txt';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);};
      closure.append(verdict,notes,exportButton,el('p','Notes stay in memory until you leave or reload. Export to your approved case system. This page does not close alerts.'));detail.append(closure);
      for(const b of Array.from(list.querySelectorAll('button'))) b.setAttribute('aria-pressed',String(b.dataset.id===selected));
    };
    const renderList=()=>{list.replaceChildren();const q=search.value.toLowerCase().trim(); const rows=data.filter(p=>(!filter.value||p.category===filter.value)&&[p.title,p.id,p.category,p.source_sheet,...p.rule_ids].join(' ').toLowerCase().includes(q)); if(!rows.length){list.append(el('p','No matching use cases'));detail.replaceChildren(el('p','Change your search or domain filter.'));return;}for(const p of rows){const b=el('button') as HTMLButtonElement;b.dataset.id=p.id;b.append(el('span',p.category,'eyebrow'),el('strong',p.title),el('small',p.rule_ids.length?'Rule '+p.rule_ids.join(', '):'Rule mapping pending'));b.onclick=()=>show(p);list.append(b);}show(rows.find(p=>p.id===selected)||rows[0]);};
    search.oninput=renderList;filter.onchange=renderList;renderList();
  };
  http.get('/api/soc_playbooks/catalogue').then((data:any)=>{if(!disposed)draw(data);}).catch(()=>{if(!disposed)status.textContent='Access unavailable. Ask your administrator to verify your SOC role and plugin configuration.';});
  return ()=>{disposed=true;state.clear();shell.remove();};
}
