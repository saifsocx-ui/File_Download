import { SocPlaybooksPlugin } from './plugin';
export const plugin = () => new SocPlaybooksPlugin();
