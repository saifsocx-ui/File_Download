import { CoreSetup, Plugin } from '../../../src/core/public';
import { mount } from './app';
import './style.scss';
export class SocPlaybooksPlugin implements Plugin {
  setup(core: CoreSetup) {
    core.application.register({ id: 'socPlaybooks', title: 'SOC Playbooks', order: 80,
      mount: async params => { const [start] = await core.getStartServices(); return mount(params.element, start.http); }
    });
  }
  start() {}
  stop() {}
}
