import { schema } from '@osd/config-schema';
import { SocPlaybooksPlugin } from './plugin';
export const config = { schema: schema.object({ allowed_backend_roles: schema.arrayOf(schema.string(), { defaultValue: [] }) }) };
export const plugin = (initializerContext: any) => new SocPlaybooksPlugin(initializerContext);
