import { CoreSetup, Plugin, PluginInitializerContext } from '../../../src/core/server';
import playbooks from '../data/playbooks.json';
export class SocPlaybooksPlugin implements Plugin {
  constructor(private readonly initializerContext: PluginInitializerContext) {}
  setup(core: CoreSetup) {
    const roles = this.initializerContext.config.get<{allowed_backend_roles: string[]}>().allowed_backend_roles;
    const router = core.http.createRouter();
    router.get({ path: '/api/soc_playbooks/catalogue', validate: false }, async (context, _request, response) => {
      const headers = { 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' };
      if (!roles.length) return response.forbidden({ body: 'SOC access has not been configured.', headers });
      try {
        const result = await context.core.opensearch.client.asCurrentUser.transport.request({ method: 'GET', path: '/_plugins/_security/authinfo' });
        const info = result.body as { backend_roles?: string[] };
        if (!Array.isArray(info.backend_roles) || !info.backend_roles.some(role => roles.includes(role))) {
          return response.forbidden({ body: 'SOC role required.', headers });
        }
        return response.ok({ body: playbooks, headers });
      } catch (_) {
        return response.forbidden({ body: 'SOC authorization could not be verified.', headers });
      }
    });
  }
  start() {}
  stop() {}
}
